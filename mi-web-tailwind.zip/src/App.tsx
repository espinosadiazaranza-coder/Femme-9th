import React from "react";

export default function App() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-purple-500 to-pink-500 text-white font-sans">
      <h1 className="text-4xl font-bold mb-4">
        🚀 Mi Web con TailwindCSS
      </h1>
      <p className="text-lg opacity-90">
        Ya tenemos estilos modernos funcionando 🎨
      </p>
      <button className="mt-6 px-6 py-2 bg-white text-purple-600 rounded-xl shadow hover:bg-purple-100 transition">
        ¡Click aquí!
      </button>
    </main>
  );
}